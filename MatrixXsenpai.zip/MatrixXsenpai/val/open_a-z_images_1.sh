#! /bin/bash
eog ./*/1.jpg
